// HTML elementlarini JS orqali yaratamiz
const style = document.createElement('style');
style.textContent = `
  html, body {
    margin: 0; padding: 0; overflow: hidden; height: 100%; background: #f0f0f0;
  }
  canvas {
    display: block; background: #fff;
  }
`;
document.head.appendChild(style);

const canvas = document.createElement('canvas');
canvas.id = 'gameCanvas';
document.body.appendChild(canvas);

const ctx = canvas.getContext('2d');

let width, height;

function resize() {
  width = window.innerWidth;
  height = window.innerHeight;
  canvas.width = width;
  canvas.height = height;
}
window.addEventListener('resize', resize);
resize();

const MAP_WIDTH = width * 3;
const MAP_HEIGHT = height * 3;

const foodColors = ['#FF3B30', '#FF9500', '#FFCC00', '#4CD964', '#5AC8FA', '#5856D6', '#FF2D55'];

const player = {
  x: Math.random() * MAP_WIDTH,
  y: Math.random() * MAP_HEIGHT,
  radius: 30,
  color: '#00AA00',
  speed: 4,
};

const foods = [];
const FOOD_COUNT = 200;

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createFoods() {
  foods.length = 0;
  for (let i = 0; i < FOOD_COUNT; i++) {
    foods.push({
      x: randomInt(20, MAP_WIDTH - 20),
      y: randomInt(20, MAP_HEIGHT - 20),
      radius: 5,
      color: foodColors[randomInt(0, foodColors.length - 1)],
    });
  }
}

createFoods();

const keys = { up:false, down:false, left:false, right:false };

window.addEventListener('keydown', e => {
  if(e.key==='ArrowUp' || e.key==='w') keys.up = true;
  if(e.key==='ArrowDown' || e.key==='s') keys.down = true;
  if(e.key==='ArrowLeft' || e.key==='a') keys.left = true;
  if(e.key==='ArrowRight' || e.key==='d') keys.right = true;
});
window.addEventListener('keyup', e => {
  if(e.key==='ArrowUp' || e.key==='w') keys.up = false;
  if(e.key==='ArrowDown' || e.key==='s') keys.down = false;
  if(e.key==='ArrowLeft' || e.key==='a') keys.left = false;
  if(e.key==='ArrowRight' || e.key==='d') keys.right = false;
});

function distance(x1,y1,x2,y2) {
  return Math.hypot(x2 - x1, y2 - y1);
}

function update() {
  if(keys.up) player.y -= player.speed;
  if(keys.down) player.y += player.speed;
  if(keys.left) player.x -= player.speed;
  if(keys.right) player.x += player.speed;

  player.x = Math.max(player.radius, Math.min(MAP_WIDTH - player.radius, player.x));
  player.y = Math.max(player.radius, Math.min(MAP_HEIGHT - player.radius, player.y));

  for(let i=foods.length-1; i>=0; i--) {
    if(distance(player.x, player.y, foods[i].x, foods[i].y) < player.radius + foods[i].radius) {
      foods.splice(i, 1);
      player.radius += 0.7;
    }
  }

  while(foods.length < FOOD_COUNT) {
    foods.push({
      x: randomInt(20, MAP_WIDTH - 20),
      y: randomInt(20, MAP_HEIGHT - 20),
      radius: 5,
      color: foodColors[randomInt(0, foodColors.length - 1)],
    });
  }
}

function draw() {
  ctx.clearRect(0, 0, width, height);
  const offsetX = player.x - width / 2;
  const offsetY = player.y - height / 2;

  for(const food of foods) {
    const screenX = food.x - offsetX;
    const screenY = food.y - offsetY;
    if(screenX + food.radius < 0 || screenX - food.radius > width ||
       screenY + food.radius < 0 || screenY - food.radius > height) continue;

    ctx.beginPath();
    ctx.fillStyle = food.color;
    ctx.arc(screenX, screenY, food.radius, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.beginPath();
  ctx.fillStyle = player.color;
  ctx.arc(width/2, height/2, player.radius, 0, Math.PI * 2);
  ctx.fill();
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

gameLoop();
